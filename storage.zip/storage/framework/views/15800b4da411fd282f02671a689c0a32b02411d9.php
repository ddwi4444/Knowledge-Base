

<?php $__env->startSection('container'); ?>

<!-- Halaman yang menampilkan detail pesan dari mahasiswa -->
<div class="container-xxl animate__animated animate__fadeIn">
    <br>
    <br>
    <hr>

    <section style="background-color: #eee;">
        <div class="container my-5 py-5">            
            <div class="row d-flex justify-content-center">
            <div class="col-md-12 col-lg-10 col-xl-8">
            <h6>Pertanyaan</h6>
                <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-start align-items-center">
                        <img class="rounded-circle shadow-1-strong me-3"
                            src="/img/user.png" alt="avatar" width="60"
                            height="60" />
                        <div>
                            <h6 class="fw-bold text-primary mb-1"><?php echo e($comment->nama); ?> - <?php echo e($comment->username); ?></h6>
                            <p class="text-muted small mb-0">
                            <?php echo e($comment->created_at); ?>

                            </p>
                        </div>
                        </div>

                        <div class="border mt-2" style="border-radius: 20px; background-color: #f2f4f5; width: fit-content;">   
                            <div style="padding-left: 10px; padding-right: 10px;">
                                <p class="mt-3">
                                    <?php echo $comment->comment; ?>

                                </p>
                            </div>                                     
                        </div>
                    </div>

                    <!-- Untuk menampilkan balasan yang telah kita buat -->
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Untuk menyaring balasan pesan yang sesuai dengan id parent -->
                    <?php if($com->id_parent == $comment->id): ?>
                    <div style="padding-left:3.5em; padding-right: 10px; bg-dark" class="mb-5">
                                <p style="color: #be5504;">Balasan <i class="bi bi-reply-all"></i></p>
                                <h6 style="color: #be5504;" class="fw-bold mb-1"><?php echo e($com->nama); ?></h6>
                                <p class="text-muted small mb-0">
                                    <?php echo e($com->created_at); ?>

                                </p>
                                <div class="border" style="border-radius: 20px; background-color: #f2f4f5; width: fit-content;">   
                                    <div style="padding-left: 10px; padding-right: 10px;">
                                        <p>
                                            <?php echo $com->comment; ?> 
                                        </p>
                                    </div>                                     
                                </div>

                                <!-- Menghapus balasan admin -->
                                <form action="<?php echo e(route('answer.destroy', $com->id)); ?>" method="Post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <!-- Button untuk mengahpus pesan dari mahasiswa -->
                                    <button type="submit" class="btn btn-danger btn-floating mt-2" data-toggle="tooltip" title='Hapus'>
                                        <i class="bi bi-trash3"></i>
                                    </button>
                                </form>

                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>               
                </div>
                
                <!-- Form untuk membalasa pesan dari mahasiswa -->
                <div class="card-footer py-3 border-0 mt-3" style="background-color: #f8f9fa;">
                    <div class="d-flex flex-start w-100 justify-content-center">
                        <form action="<?php echo e(route('answer.store', $comment)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>  
                            
                            <div class="form-group mt-2">
                                <label for="balasan">Balas Pertanyaan</label>
                                <textarea
                                    name="balasan" id="editor"
                                    class="form-control"
                                    rows="5" 
                                    oninput="setCustomValidity('')" oninvalid="this.setCustomValidity('Balasan wajib diisi !')"
                                    required><?php echo e(old('balasan')); ?></textarea>

                                <!-- error message untuk deskripsi -->
                                <?php $__errorArgs = ['balasan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6 mt-2">
                                    <select name="status" required>
                                        <option value="" disabled selected >Pilih Tampilkan atau Tidak</option>
                                        <option value="1">Tampilkan</option>
                                        <option value="2">Tidak Tampilkan</option>
                                    </select>
                            </div>


                            <div class="float-start mt-2">
                                <button type="submit" class="btn btn-primary btn-sm">Kirim Balasan</button>
                                <a href="<?php echo e(route('pertanyaan')); ?>" class="btn btn-outline-primary btn-sm">Kembali</a>
                            </div>
                            
                        </form>
                </div>
            </div>
            </div>
        </div>
    </section>

    <br>
    <br>
    <br>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    CKEDITOR.replace( 'editor' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/pertanyaan/show.blade.php ENDPATH**/ ?>