

<?php $__env->startSection('container'); ?>

<div class="container-xxl animate__animated animate__fadeIn">
    <br>
    <br>
    <hr>

    <header class="w3-container w3-center w3-padding-32 text-align-center"> 
    
    <h1 class="text-center"><b><?php echo e($post->judul_post); ?></b></h1>
    <p class="text-center"><?php echo e($post->created_at); ?></p>
    </header>

    <div class="text-justify">
        <p class="text-justify"><?php echo $post->isi_post; ?></p> 
    </div>

    <section style="background-color: #eee;">
        <div class="container my-5 py-5">            
            <div class="row d-flex justify-content-center">
            <div class="col-md-12 col-lg-10 col-xl-8">
            <h6>Pertanyaan</h6>
                <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-start align-items-center">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    var_dump<?php echo e($comments); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="card-footer py-3 border-0 mt-3" style="background-color: #f8f9fa;">
                    <h6>Tinggalkan Pertanyaan</h6>
                    <div class="d-flex flex-start w-100 justify-content-center">
                        <form action="<?php echo e(route('comment.store', $post)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>  

                            <div class="form-group float-start mt-2 pt-2">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="nama" id="nama" value="<?php echo e(old('nama', $post->nama)); ?>" required>

                                <!-- error message untuk title -->
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group float-end mt-2 pt-2 m-2">
                                <label for="email">Email Student</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    pattern=".+@students.uajy.ac.id" name="email" id="email" placeholder="npm@students.uajy.ac.id" value="<?php echo e(old('email', $post->email)); ?>" required>

                                <!-- error message untuk title -->
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mt-2">
                                <label for="komentar">Pertanyaan</label>
                                <textarea
                                    name="komentar" id="editor"
                                    class="form-control <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-100"
                                    rows="5"
                                    required><?php echo e(old('komentar')); ?></textarea>

                                <!-- error message untuk deskripsi -->
                                <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="float-start mt-2">
                                <button type="submit" class="btn btn-primary btn-sm">Ajukan Pertanyaan</button>
                                <a href="<?php echo e(route('show', $post->slug)); ?>" class="btn btn-outline-primary btn-sm">Batal</a>
                            </div>

                            

                        </form>                       
                    
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>




    <br>
    <br>
    <br>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/post\show.blade.php ENDPATH**/ ?>