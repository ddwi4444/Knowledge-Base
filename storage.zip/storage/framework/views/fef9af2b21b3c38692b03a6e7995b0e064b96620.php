

<?php $__env->startSection('container'); ?>
<br>
<br>
<br>
<!-- Halaman login admin -->
<div class="row justify-content-center">
    <div class="col-md-4">

    <!-- Alert jika  login sukses-->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible animate__animated animate__fadeInDown" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria label="Tutup">
                </button>
            </div>
        <?php endif; ?>

        <!-- Form Login -->
        <h1 class="h4 mb-auto mt-5 fw-normal text-center animate__animated animate__fadeInDown">PENELITIAN - LPPM</h1>
        <br>        
        <main class="form-signin border-3 mb-8 animate__animated animate__fadeInDown">
            <form action="/login" method="post">
                    <?php echo csrf_field(); ?>
                    <center><img class="mb-4" src="/img/Logo.png" alt="" width="30%"></center>
                    <h1 class="h5 mb-3 text-center">Universitas<br>Atma Jaya Yogyakarta</h1>

                    <!-- Input email -->
                    <div class="form-floating">
                    <input type="username" name="username" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="username" placeholder="name@example.com" autofocus required value="<?php echo e(old ('username')); ?>">
                    <label for="username">Email address</label>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Input password -->
                    <div class="form-floating">
                    <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
                    <label for="password">Password</label>
                    </div>

                    <div class="checkbox mb-3">
                    </div>
                    <button class="w-100 btn btn-lg btn-primary text-slate-600" type="submit">Sign in</button>
            </form>
        </main>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/login/index.blade.php ENDPATH**/ ?>