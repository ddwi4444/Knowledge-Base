

<?php $__env->startSection('container'); ?>
<br>
<br>

<!-- Halaman untuk dashboard pesan oleh mahasiswa untuk admin -->
<h3 class="animate__animated animate__fadeIn">Pertanyaan</h3>
<br>

<table class="table animate__animated animate__fadeIn">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Username</th>
      <th scope="col">Nama</th>
      <th scope="col">Pertanyaan</th>
      <th scope="col">Tanggal</th>
      <th scope="col">Status Tampil</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <!-- Kondisi untuk menampilkan pesan hanya dari mahasiswa, jadi membutuhkan pesan/comment yang tidak memiliki id parent -->
  <?php if($comment->id_parent == NULL): ?>
    <tr>
      <td><?php echo e($loop->iteration); ?></td>
      <td><?php echo e($comment->username); ?></td>
      <td><?php echo e($comment->nama); ?></td>
      <td class="col-sm-3"><?php echo e($comment->comment); ?></td>
      <td><?php echo e($comment->created_at->format('d, M Y')); ?></td>
      <td>
          <?php if($comment->status == 0): ?>
          <!-- Tanda pertanyaan masi baru -->
            <p class="text-info">Pesan Baru</p>            
          <?php elseif($comment->status == 2): ?>
          <!-- Button untuk menampilkan pesan -->
            <a href="<?php echo e(route('changeStatus', $comment->id)); ?>"
              class="btn btn-sm btn-warning shadow"><i class="bi bi-x-square"></i> Tidak Tampil</i></a>
          <?php else: ?>
          <!-- Button untuk tidak menampilkan pesan -->
            <a href="<?php echo e(route('changeStatusNonaktif', $comment->id)); ?>"
            class="btn btn-sm btn-primary shadow"><i class="bi bi-check-square"></i> Tampil</i></a>  
          <?php endif; ?>
      </td>
      <td>
        <form
          action="<?php echo e(route('comment.destroy', $comment->id)); ?>" method="Post">
          <!-- Button untuk masuk ke halaman detail pesan oleh mahasiswa -->
          <a href="<?php echo e(route('showComment', $comment->id)); ?>"
            class="btn btn-sm btn-light shadow">Detail
          </a>
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <!-- Button untuk mengahpus pesan dari mahasiswa -->
          <button type="submit" class="btn btn-sm btn-danger show_confirm" data-toggle="tooltip" title='Delete'>Hapus</button>
        </form>
      </td>
    </tr>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<!-- Warning untuk menyetujui pesan dihapus atau tidak -->
<script type="text/javascript">
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Apakah anda yakin ingin menghapus postingan ini?`,
              text: "Jika anda setuju, maka postingan ini akan dihapus permanent",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/pertanyaan/index.blade.php ENDPATH**/ ?>