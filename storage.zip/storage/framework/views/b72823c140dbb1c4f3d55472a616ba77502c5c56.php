

<?php $__env->startSection('container'); ?>
<br>
<br>
<!-- Merupakan halaman dashboard admin -->
<h3 class="animate__animated animate__fadeIn">My Post</h3>
<br>

<!-- Button untuk menambah post oleh admin -->
<div class="col-md-2 animate__animated animate__fadeIn">
  <p><a class="btn text-capitalize" href="<?php echo e(route('posts.create')); ?>">Tambah Post </a></p>
</div>

<!-- Input untuk mencari post oleh admin -->
<form action="/dashboard/cari" method="GET" class="input-group rounded mt-4 w-25 animate__animated animate__fadeIn">
		<input type="text" class="form-control rounded" name="cari" placeholder="Cari.." value="<?php echo e(old('cari')); ?>">
		<span class="input-group-text border-0" id="search-addon">
      <i class="bi bi-search"></i>
    </span>
</form>

<!-- Table untuk menampilkan daftar post yang telah dibuat oleh admin -->
<table class="table animate__animated animate__fadeIn container">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Judul</th>
      <th scope="col">Tanggal</th>
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody>
    <!-- Perulangan Post -->
  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($loop->iteration); ?></td>
      <td class="col-sm-5"><?php echo e($post->judul_post); ?></td>
      <td><?php echo e($post->created_at); ?></td>
      <td>
              <form
                action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                <!-- Button untuk melihat detail post -->
                <a href="<?php echo e(route('show', ['id_unit'=>$post->id_unit, 'slug'=>$post->slug])); ?>"
                  class="btn btn-sm btn-light shadow">Detail</a>
                  <!-- Button untuk edit post -->
                <a href="<?php echo e(route('posts.edit', $post->id)); ?>"
                    class="btn btn-sm btn-info shadow">Edit</a>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <!-- Button untuk menghapus post -->
                <button type="submit" class="btn btn-sm btn-danger shadow show_confirm" data-toggle="tooltip" title='Delete'>Delete</button>
            </form>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<!-- Warning untuk menyetujui pesan dihapus atau tidak -->
<script type="text/javascript">
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Apakah anda yakin ingin menghapus postingan ini?`,
              text: "Jika anda setuju, maka postingan ini akan dihapus permanent",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/dashboard/index.blade.php ENDPATH**/ ?>