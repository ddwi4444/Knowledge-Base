

<?php $__env->startSection('container'); ?>
<!-- Halaman untuk menampilkan single post -->

<div class="container-xxl animate__animated animate__fadeIn">
    <br>

    <ul id="menu">
        <li><a href="<?php echo e(route('/')); ?>">Knowledge Base</a></li>
        <li>></li>
        <li><a href="<?php echo e(route('unit.posts', $post->id_unit)); ?>"><?php echo e($post->id_unit); ?></a></li>
        <li>></li>
        <li><a href="<?php echo e(route('show', ['id_unit'=>$post->id_unit, 'slug'=>$post->slug])); ?>"><?php echo e($post->judul_post); ?></a></li>
    </ul>  
    
    <hr>

    <header class="w3-container w3-center w3-padding-32 text-align-center"> 
    <h1 class="text-center"><b><?php echo e($post->judul_post); ?></b></h1>
    <p class="text-center"><?php echo e($post->created_at->diffForHumans()); ?></p>
    </header>

    <div class="text-justify mb-5">
        <p class="text-justify"><?php echo $post->isi_post; ?></p> 
    </div>

    <!-- Pertanyaan terkait -->
    <div class="slider">
    <h6 class="bbb_viewed_title">Pertanyaan terkait :</h6>
        <div class="slider__wrapper">
            <!-- Untuk memanggil data mengenai pertanyaan terkait -->
            <?php $__currentLoopData = $relatedPosts->slice(0, 16); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rpost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Untuk memilah data agar sesuai dengan tags dan seusai dengan id unit yang sama -->
            <?php if($rpost->id_unit == $post->id_unit && $rpost->id != $post->id): ?>
            <div class="slider__item">
                    <a href="<?php echo e(route('show', ['id_unit'=>$rpost->id_unit, 'slug'=>$rpost->slug] )); ?>">
                    <div class="card__header_post text-dark bbb_viewed_name">
                        <img class="img_post" src="<?php echo e(asset('storage/'.$rpost->image)); ?>" alt="card__image" class="card__image" width="600">
                    </div>
                    <p><?php echo e(Str::limit($rpost->judul_post, 30)); ?></p></a>
                    <p><?php echo e($rpost->created_at->diffForHumans()); ?></p>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="slider__control slider__control_left" href="#" role="button"></a>
        <a class="slider__control slider__control_right slider__control_show" href="#" role="button"></a>
    </div>

    <!-- Comment -->
    <section style="background-color: #eee;">
        <div class="container my-5 py-5">            
            <div class="row d-flex justify-content-center">
            <div class="col-md-12 col-lg-10 col-xl-8">
            <h6>Pertanyaan</h6>

            <!-- Untuk memanggil data pesan pada post ini -->
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Untuk menyaring psean yang sesuai dengan id post  -->
            <?php if($comment->id_post == $post->id && $comment->id_parent == NULL && $comment->status == 1): ?>
                <div class="card">                
                <div class="card-body d-flex flex-fill">                    
                    <div class="d-flex flex-start align-items-center">
                        <div>
                            <h6 class="fw-bold text-primary mb-1"><?php echo e($comment->nama); ?></h6>
                            <p class="text-muted small mb-0">
                            <?php echo e($comment->created_at); ?>

                            </p>

                            <div class="border" style="border-radius: 20px; background-color: #f2f4f5; width: fit-content; margin-bottom: 10px;">   
                                <div style="padding-left: 10px; padding-right: 10px;">
                                    <p class="mt-3">
                                        <?php echo $comment->comment; ?>

                                    </p>
                                </div>                                     
                            </div>

                            <!-- Untuk memanggil data balasan pesan dari admin -->
                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Untuk menyaring balasan pesan yang sesuai dengan id parent -->
                                <?php if($com->id_parent == $comment->id): ?>
                                    <div style="padding-left:3.5em; bg-dark">
                                        <p style="color: #be5504;">Balasan <i class="bi bi-reply-all"></i></p>
                                        <h6 style="color: #be5504;" class="fw-bold mb-1"><?php echo e($com->nama); ?></h6>
                                        <p class="text-muted small mb-0">
                                            <?php echo e($com->created_at); ?>

                                        </p>
                                        <div class="border" style="border-radius: 20px; background-color: #f2f4f5; width: fit-content;">   
                                            <div style="padding-left: 10px; padding-right: 10px;">
                                                <p>
                                                    <?php echo $com->comment; ?>

                                                </p>
                                            </div>                                     
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <hr>
                        
                            </div>
                        </div>                    
                    </div>
                </div>                
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Form input untuk pesan mahasiswa -->
                <div class="card-footer py-3 border-0 mt-3" style="background-color: #f8f9fa;">
                    <h6>Tinggalkan Pertanyaan</h6>
                    <div class="d-flex flex-start w-100 justify-content-center">
                        <form action="<?php echo e(route('pertanyaan.store', $post)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('post'); ?>  

                            <div class="form-group float-start mt-2 pt-2">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="nama" id="nama" 
                                    oninput="setCustomValidity('')" oninvalid="this.setCustomValidity('Nama wajib diisi !')"
                                    placeholder="Nama Lengkap"  value="<?php echo e(old('nama')); ?>" required>

                                <!-- error message untuk title -->
                                <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group float-end mt-2 pt-2 m-2">
                                <label for="email">Email Student</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    pattern=".+@students.uajy.ac.id" oninput="setCustomValidity('')"
                                    oninvalid="this.setCustomValidity('Hanya dapat menggunakan email student !')"
                                    name="email" id="email" placeholder="npm@students.uajy.ac.id" value="<?php echo e(old('email')); ?>" required>
                            </div>

                            <div class="form-group mt-2">
                                <label for="komentar">Pertanyaan</label>
                                <textarea
                                    name="komentar" id="editor"
                                    class="form-control <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> w-100"
                                    rows="5"
                                    placeholder="Pertanyaan"
                                    oninput="setCustomValidity('')"
                                    oninvalid="this.setCustomValidity('Pertanyaan wajib diisi !')"
                                    required><?php echo e(old('komentar')); ?></textarea>

                                <!-- error message untuk deskripsi -->
                                <?php $__errorArgs = ['komentar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group float-start mt-2">
                            <?php echo NoCaptcha::renderJs(); ?>

                            <?php echo NoCaptcha::display(); ?>

                            </div>

                            <div class="form-group float-end mt-2">
                                <button type="submit" class="btn btn-primary btn-sm">Ajukan Pertanyaan</button>
                                <a href="<?php echo e(route('show', ['id_unit'=>$post->id_unit, 'slug'=>$post->slug])); ?>" class="btn btn-outline-primary btn-sm">Batal</a>
                            </div>
                            

                        </form>                       
                    
                </div>
                </div>
            </div>
            </div>
        </div>
    </section>




    <br>
    <br>
    <br>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/post/show.blade.php ENDPATH**/ ?>