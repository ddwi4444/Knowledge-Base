

<?php $__env->startSection('container'); ?>
<br>
<br>
<!-- Halaman untuk mengubah password -->
    <div class="container mt-4 animate__animated animate__fadeIn">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header h4">
                        Update Password
                    </div>

                    <div class="card-body">

                        <?php if(session('success')): ?>
                            <div class="alert alert-success" role='alert'>
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('password.edit')); ?>">
                            <?php echo method_field('patch'); ?>
                            <?php echo csrf_field(); ?>

                            <!-- Input untuk password sekarang -->
                            <div class="form-group row">
                                <label for="old_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Current Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="old-password" type="password" class="form-control" name="old_password">

                                    <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mb-2">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Input untuk password yang baru -->
                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="text-danger mb-2">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <!-- Input untuk konfirmasi password terbaru -->
                            <div class="form-group row">
                                <label for="password_onfirmation" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm New Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="password_confirmation" type="password" class="form-control" name="password_confirmation">
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary text-slate-600">
                                        Update Password
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Magang KSI\xamp\htdocs\KnowledgeBase\resources\views/password/edit.blade.php ENDPATH**/ ?>